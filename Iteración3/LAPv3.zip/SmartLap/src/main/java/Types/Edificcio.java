package Types;

public class Edificcio {
 public static Integer plantas;
 public static Integer Pisoactual;
}
