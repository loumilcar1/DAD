package Types;

public class Dispositivo {
	private int idDispositivo;
	private int idEdificio;
	
	
	public Dispositivo(int idDispositivo, int idEdificio) {
		super();
		this.idDispositivo = idDispositivo;
		this.idEdificio = idEdificio;
	}


	public Dispositivo() {
		super();
	}


	public int getIdDispositivo() {
		return idDispositivo;
	}


	public void setIdDispositivo(int idDispositivo) {
		this.idDispositivo = idDispositivo;
	}


	public int getIdEdificio() {
		return idEdificio;
	}


	public void setIdEdificio(int idEdificio) {
		this.idEdificio = idEdificio;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idDispositivo;
		result = prime * result + idEdificio;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dispositivo other = (Dispositivo) obj;
		if (idDispositivo != other.idDispositivo)
			return false;
		if (idEdificio != other.idEdificio)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Dispositivo [idDispositivo=" + idDispositivo + ", idEdificio=" + idEdificio + "]";
	}

	
	
	
	
}
