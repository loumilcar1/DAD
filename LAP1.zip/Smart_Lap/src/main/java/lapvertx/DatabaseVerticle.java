package lapvertx;


import io.vertx.core.AbstractVerticle;
import io.vertx.core.Handler;
import io.vertx.core.Promise;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.ext.web.impl.RoutingContextImpl;
import io.vertx.mysqlclient.MySQLClient;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;
import Types.Edificcio;
import Types.Sensores;

public class DatabaseVerticle extends AbstractVerticle{
	
	private MySQLPool mySQLPool;
	
	@Override
	public void start(Promise<Void> startPromise) {
		MySQLConnectOptions mySQLConnectOptions = new MySQLConnectOptions().setPort(3306).setHost("localhost")
				.setDatabase("lap").setUser("root").setPassword("root");
		PoolOptions poolOptions = new PoolOptions().setMaxSize(5);
		mySQLPool = MySQLPool.pool(vertx, mySQLConnectOptions, poolOptions);
		
		Router router = Router.router(vertx);
		router.route().handler(BodyHandler.create());

		vertx.createHttpServer().requestHandler(router::handle).listen(8080, result -> {
			if (result.succeeded()) {
				startPromise.complete();
			}else {
				startPromise.fail(result.cause());
			}
		});
		
		router.get("/lap/dispositivo/pisoconhumedad/:IdEdificio/:location").handler(this::getpisoconhumedad);
		router.get("/lap/dispositivo/pisocalor/:IdEdificio/:location").handler(this::getpisodondehacecalor);
		router.get("/lap/dispositivo/pisofrio/:IdEdificio/:location").handler(this::getpisodondehacefrio);
		router.get("/lap/dispositivo/pisosconhumedad/:IdEdificio").handler(this::getpisosconhumedad);
		router.get("/lap/dispositivo/edificiofrio/:IdEdificio").handler(this::getpisosdondehacefrio);
		router.get("/lap/dispositivo/edificiocalor/:IdEdificio").handler(this::getpisoscalor);
		router.get("/lap/dispositivo/values/:idDispositivo").handler(this::getValueByDispositivo);
		router.get("/lap/dispositivo/values/:idSensor/:timestamp").handler(this::getValueBySensorAndTimestamp);
		router.get("/lap/sensor/values/:idSensor").handler(this::getValueBySensor);
		router.put("/lap/sensor/values").handler(this::putvalueSensor);
	}
	private void putvalueSensor(RoutingContext context) {
		Sensores sensores= Json.decodeValue(context.getBodyAsString(),Sensores.class);
		mySQLPool.preparedQuery("INSERT INTO `lap`.`sensores` (`idDispositivo`, `temperatura`, `humedad`, `calidad_aire`, `timestamp`, `location`) VALUES (?, ?, ?, ?, ?, ?);" + 
				"",
				Tuple.of(sensores.getIdDispositivo(),sensores.getTemperatura(),sensores.getHumedad(),sensores.getCalidad_aire(),sensores.getTimestamp(),sensores.getLocation()),
				handler ->{
					if(handler.succeeded()) {
						System.out.println(handler.result().rowCount());
						Long id= handler.result().property(MySQLClient.LAST_INSERTED_ID);
						//sensores.setIdSensor((int) id);
						context.response().setStatusCode(200).putHeader("content-type", "application/json").end(JsonObject.mapFrom(sensores).encodePrettily());;
					}else {
						System.out.println(handler.cause().toString());
						context.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end((JsonObject.mapFrom(handler.cause()).encodePrettily()));
					}
				});
		
	}
	private void getpisosconhumedad(RoutingContext routingContext) {
		
		mySQLPool.query("SELECT  sensores.*  FROM lap.sensores,  dispositivo  where  dispositivo.idDispositivo=sensores.idDispositivo and idEdificio="+routingContext.request().getParam("IdEdificio")+"  and humedad > 60 group by location order by timestamp desc limit 100"
						+routingContext.request().getParam("idEdificio"), 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(row);
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
							System.out.println(result);
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
		
		
		
		
	}
private void getpisoconhumedad(RoutingContext routingContext) {
		
		mySQLPool.query("SELECT  sensores.*  FROM lap.sensores,  dispositivo  where  dispositivo.idDispositivo=sensores.idDispositivo and idEdificio="+routingContext.request().getParam("IdEdificio")+" and location="+routingContext.request().getParam("location")+" and humedad > 60 group by location order by timestamp desc limit 100"
						+routingContext.request().getParam("idEdificio") + routingContext.request().getParam("location") , 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(row);
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
							System.out.println(result);
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
		
		
		
		
	}
private void getpisodondehacecalor(RoutingContext routingContext) {
		
		mySQLPool.query("SELECT  sensores.*  FROM lap.sensores,  dispositivo  where  dispositivo.idDispositivo=sensores.idDispositivo and idEdificio="+routingContext.request().getParam("IdEdificio")+" and location="+routingContext.request().getParam("location")+" and temperatura> 28 group by location order by timestamp desc limit 100"
						+routingContext.request().getParam("idEdificio") + routingContext.request().getParam("location") , 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(row);
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
							System.out.println(result);
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
		
		
		
		
	}
private void getpisodondehacefrio(RoutingContext routingContext) {
	
	mySQLPool.query("SELECT  sensores.*  FROM lap.sensores,  dispositivo  where  dispositivo.idDispositivo=sensores.idDispositivo and idEdificio="+routingContext.request().getParam("IdEdificio")+" and location="+routingContext.request().getParam("location")+" and temperatura< 26 group by location order by timestamp desc limit 100"
					+routingContext.request().getParam("idEdificio") +routingContext.request().getParam("location"), 
			res -> {
				if (res.succeeded()) {
					RowSet<Row> resultSet = res.result();
					System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
					JsonArray result = new JsonArray();
					
					for (Row row : resultSet) {
						System.out.println(row);
						result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
								row.getInteger("idDispositivo"),
								row.getFloat("temperatura"),
								
								row.getFloat("humedad"),
								row.getInteger("calidad_aire"),
								row.getLong("timestamp"),
								row.getInteger("location"))));
						System.out.println(result);
					}
					
					routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
						.end(result.encodePrettily());
				}else {
					routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
				}
			});
	
	
	
	
}
	private void getValueBySensorAndTimestamp(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM lap.sensores WHERE timestamp > " + 
						routingContext.request().getParam("timestamp") + " AND idsensor = " + 
						routingContext.request().getParam("idSensor"), 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
	}
	private void getValueByDispositivo(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM lap.sensores WHERE idDispositivo= " + 
						routingContext.request().getParam("idDispositivo"), 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
	}
	private void getpisoscalor(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM lap.sensores , lap.edificio, lap.dispositivo WHERE temperatura > 26 and edificio.idEdificio= "+
				routingContext.request().getParam("idEdificio") +" and "
				+ "dispositivo.idDispositivo=sensores.idDispositivo and edificio.idEdificio=dispositivo.idEdificio ;", 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(resultSet);
							Sensores d = new Sensores();
							d.setLocation(row.getInteger("location"));
							result.add(JsonObject.mapFrom(d.getLocation()));
							
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
	}
	private void getpisosdondehacefrio(RoutingContext routingContext) {
		
		mySQLPool.query("SELECT  sensores.*  FROM lap.sensores,  dispositivo  where  dispositivo.idDispositivo=sensores.idDispositivo and idEdificio="+routingContext.request().getParam("IdEdificio")+"  and temperatura< 20 group by location order by timestamp desc limit 100"
						+routingContext.request().getParam("idEdificio"), 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(row);
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
							System.out.println(result);
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
		
		
		
		
	}
	private void getValueBySensor(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM lap.sensores WHERE idSensor = " + routingContext.request().getParam("idSensor"), 
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("El n�mero de elementos obtenidos es " + resultSet.size());
						JsonArray result = new JsonArray();
						
						for (Row row : resultSet) {
							System.out.println(row);
							result.add(JsonObject.mapFrom(new Sensores(row.getInteger("idSensor"),
									row.getInteger("idDispositivo"),
									row.getFloat("temperatura"),
									
									row.getFloat("humedad"),
									row.getInteger("calidad_aire"),
									row.getLong("timestamp"),
									row.getInteger("location"))));
							System.out.println(result);
						}
						
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
							.end(result.encodePrettily());
					}else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
							.end((JsonObject.mapFrom(res.cause()).encodePrettily()));
					}
				});
	}

}
