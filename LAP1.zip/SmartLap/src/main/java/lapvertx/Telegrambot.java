package lapvertx;

import javax.swing.plaf.basic.BasicScrollPaneUI.HSBChangeListener;

import org.schors.vertx.telegram.bot.LongPollingReceiver;
import org.schors.vertx.telegram.bot.TelegramBot;
import org.schors.vertx.telegram.bot.TelegramOptions;
import org.schors.vertx.telegram.bot.api.methods.SendMessage;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;

public class Telegrambot extends AbstractVerticle{
	private TelegramBot bot;
	private String variable=null;
	@Override
	public void start(Promise<Void> future) {
		TelegramOptions options=new TelegramOptions().setBotName("Vertexgusdad_bot").setBotToken("1113833434:AAH2H8GjXEnuWkPXWC_rvSV2zYjR2BI7HcY");
		bot =TelegramBot.create(vertx,options).receiver(new LongPollingReceiver().onUpdate(handler->{
			if(handler.getMessage().getText().toLowerCase().contains("hola")) {
				bot.sendMessage(new SendMessage().setText("Hola "+ handler.getMessage().getFrom().getFirstName()+" �En que puedo ayudarte?")
						.setChatId(handler.getMessage().getChatId()));
			}else if (variable==null){
				if(handler.getMessage().getText().toLowerCase().contains("calor")) {
					bot.sendMessage(new SendMessage().setText("�de que piso?").setChatId(handler.getMessage().getChatId()));
					variable="calor";}
				else if(handler.getMessage().getText().toLowerCase().contains("frio")) {
						bot.sendMessage(new SendMessage().setText("�de que piso?").setChatId(handler.getMessage().getChatId()));
						variable="frio";
				}
				else if(handler.getMessage().getText().toLowerCase().contains("aire")) {
					bot.sendMessage(new SendMessage().setText("�de que piso?").setChatId(handler.getMessage().getChatId()));
					variable="contaminacion";
				}
				else if(handler.getMessage().getText().toLowerCase().contains("tempe")) {
					bot.sendMessage(new SendMessage().setText("�de que piso?").setChatId(handler.getMessage().getChatId()));
					variable="tempe";
				
				}else if(handler.getMessage().getText().toLowerCase().contains("hume")) {
					bot.sendMessage(new SendMessage().setText("�de que piso?").setChatId(handler.getMessage().getChatId()));
					variable="tempe";
				
				}
			}else {
				if(variable=="calor" ) {
				WebClient client= WebClient.create(vertx);
				
				client.get(8080,"localhost","/lap/dispositivo/pisocalor/1/"+handler.getMessage().getText()).send(ar->{
					if(ar.succeeded()) {
						HttpResponse<Buffer> response =ar.result();
						JsonArray object =response.bodyAsJsonArray();
						System.out.println(object);
						
						if (object.isEmpty()) {
							
							bot.sendMessage(new SendMessage().setText("que co�o va hacer calor").setChatId(handler.getMessage().getChatId()));
							variable=null;
						}else {
							Float temp=  object.getJsonObject(0).getFloat("temperatura");
							bot.sendMessage(new SendMessage().setText("sii hace calor, la temperatura es de "+temp+". Deja de molesta, que me estoy echando la siesta ").setChatId(handler.getMessage().getChatId()));
							variable=null;
									
						}
						
					}else {
						bot.sendMessage(new SendMessage().setText("Algo se ha ido a la puta").setChatId(handler.getMessage().getChatId()));
						variable=null;
					}
				});;
			};
			if(variable=="frio" ) {
				WebClient client= WebClient.create(vertx);
				
				client.get(8080,"localhost","/lap/dispositivo/pisofrio/1/"+handler.getMessage().getText()).send(ar->{
					if(ar.succeeded()) {
						HttpResponse<Buffer> response =ar.result();
						JsonArray object =response.bodyAsJsonArray();
						System.out.println(object);
						
						if (object.isEmpty()) {
							
							bot.sendMessage(new SendMessage().setText("mirame aqui con el abanico ").setChatId(handler.getMessage().getChatId()));
							variable=null;
						}else {
							Float temp=  object.getJsonObject(0).getFloat("temperatura");
							bot.sendMessage(new SendMessage().setText("que si hace frio, la temperatura es de "+temp+". me estoy congelando los huevos ").setChatId(handler.getMessage().getChatId()));
							variable=null;
									
						}
						
					}else {
						bot.sendMessage(new SendMessage().setText("Algo se ha ido a la puta").setChatId(handler.getMessage().getChatId()));
						variable=null;
					}
				});;
			};
		}
			}));
		bot.start();
	}
}
